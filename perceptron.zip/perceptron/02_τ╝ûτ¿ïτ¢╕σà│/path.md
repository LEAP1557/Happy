


行动路径思路；--> 相应code


日数据
time 模块时间序列
整理日指标



功能：
- 周期趋势呈现业绩
	- 可视化图表
	- 现状表述--直接输出语句
- 预测  ： prophet --> 可行性低
- 异常波动判定
	- 判定逻辑：参考网上资料，储存在公司电脑
	- 实施
		- 指标加工，排序， lambda
		- 条件语句
	- 邮件触达
- 品类相关  
	- 判定逻辑
		- 商城
		- 白条
		- 渗透率
		- 相对数值
			- 占全盘比
			- 距均值差值
	- 运营逻辑
		- 盘子-交易额
		- sku集中度，商家集中度  （完全竞争市场，寡头市场）
	- 品类营销判定--难
		-  和coupon表关联
		- 参考CAPM 进行评价
	- 操作逻辑
		- 历史数据，发现规律，发现趋势
		- 沉淀经验数据
		- 条件判断异常情况
		- 发展评价逻辑  
- 不同指标相关，因果，互相影响？
	- 可视化看规律
	- 思路参考原则
- 指标衍生逻辑：环比、同比 、移动平均环比同比
- 差异度判定：
	- Variance
	- 熵



自己的时限还是需要拉长一些看

语法重新熟悉
lamba
def  语句学习
条件，判断， 整列加减乘除



收入
息费
通道收入
B端收入（忘记是否有前置code了）
资金成本（ 交易折算 ）
通道成本  （交易折算）
首单费用
期间费用
参数：分期占比、付费分期占比、付费分期人数  、 拆交易月份


风险成本（同样分区满足）--单独出



--------
### 0301
问题：range（） 数据类型？



目标：
量化交易编程技能基础
系统邮件生成流程 code
https://www.runoob.com/python3/python3-smtp.html
http://www.imooc.com/wiki/officeautomation/htmlandannex.html

推导式这种方式能都快速帮我们生成我们想要的列表，集合或者字典等等。极大的加快了我们的开发速度。假如你是一位测试人员，需要大量的假数据来测试程序，这个时候推导式这种方式就很适合你。
这节课我们学习了函数的参数，参数这个概念是函数使用中不可缺少的一环。在函数定义时的参数叫做"形参"，而在函数调用时的参数叫做"实参"。一定要分清这两个概念。
  

迭代是Python最强大的功能之一，是访问集合元素的一种方式。
迭代器是一个可以记住遍历的位置的对象。
迭代器对象从集合的第一个元素开始访问，直到所有的元素被访问完结束。迭代器只能往前不会后退。
迭代器有两个基本的方法：**iter()** 和 **next()**。
字符串，列表或元组对象都可用于创建迭代器
迭代器对象可以使用常规for语句进行遍历：

在 Python 中，使用了 yield 的函数被称为生成器（generator）。
跟普通函数不同的是，**生成器是一个返回迭代器的函数**，只能用于迭代操作，更简单点理解生成器就是一个迭代器。

交互式编程和脚本式编程
- 数据格式
- 逻辑
	- 循环语句
	- for 语句
- 推导式--更快输入
	- 格式
	- if 条件函数筛选 （无else）
	- for 循环嵌套
		- 单独装饰器
		- 双for  append
	- for+ if： 先for 后if
	- 列表 、集合、字典
- 函数定义--重复化逻辑固化
- 函数参数
	- 默认、可变、关键字
	- 实参和形参
- [面向对象逻辑 ](https://www.runoob.com/python3/python3-class.html)
	*  ***类(Class):** 用来描述具有相同的属性和方法的对象的集合。它定义了该集合中每个对象所共有的属性和方法。对象是类的实例。
		* 属性 x.i
		* 方法  x.f()
			* 类有一个名为 `__init__() `的特殊方法（**构造方法**），该方法在<u>类实例化</u>时会自动调用 x = MyClass()
	-   **方法**:  类中定义的函数。
	-   **类变量**：类变量在整个实例化的对象中是公用的。类变量定义在类中且在函数体之外。类变量通常不作为实例变量使用。
	- **实例变量**：在类的声明中，属性是用变量来表示的，这种变量就称为实例变量，实例变量就是一个用 self 修饰的变量。
	-   **数据成员**：类变量或者实例变量用于处理类及其实例对象的相关的数据。
	-   **方法重写**：如果从父类继承的方法不能满足子类的需求，可以对其进行改写，这个过程叫方法的覆盖（override），也称为方法的重写。
	-   **局部变量**：定义在方法中的变量，只作用于当前实例的类。
	-  继承：即一个派生类（derived class）继承基类（base class）的字段和方法。继承也允许把一个派生类的对象作为一个基类对象对待。例如，有这样一个设计：一个Dog类型的对象派生自Animal类，这是模拟"是一个（is-a）"关系（例图，Dog是一个Animal）。
	-   实例化：创建一个类的实例，类的具体对象
	- <u> 对象：通过类定义的数据结构实例。对象包括两个数据成员（类变量和实例变量）和方法。</u>
- 命名空间和作用域  
	- 命名空间**局部的命名空间 -> 全局命名空间 -> 内置命名空间**。
		-   **内置名称（built-in names**）， Python 语言内置的名称，比如函数名 abs、char 和异常名称 BaseException、Exception 等等。
		-   **全局名称（global names）**，模块中定义的名称，记录了模块的变量，包括函数、类、其它导入的模块、模块级的变量和常量。
		-   **局部名称（local names）**，函数中定义的名称，记录了函数的变量，包括函数的参数和局部定义的变量。（类中定义的也是）
	- 作用域  **L –> E –> G –> B**。
		- -   **L（Local）**：最内层，包含局部变量，比如一个函数/方法内部。
		-   **E（Enclosing）**：包含了非局部(non-local)也非全局(non-global)的变量。比如两个嵌套函数，一个函数（或类） A 里面又包含了一个函数 B ，那么对于 B 中的名称来说 A 中的作用域就为 nonlocal。
		-   **G（Global）**：当前脚本的最外层，比如当前模块的全局变量。
		-   **B（Built-in）**： 包含了内建的变量/关键字等，最后被搜索。
	- 全局变量和局部变量
	- global & nonlocal 关键字
		- 函数外  global
		- 嵌套作用域 enclosing 作用域   nonlocal
- 标准库概览
	- ·os 模块
	- math 模块
	- global 模块
	- urllib.request 以及用于发送电子邮件的 smtplib 模块
	- datetime模块为日期和时间处理同时提供了简单和复杂的方法。
- 其他系统知识
	- 输入和输出  read & write
	- 输入和输出
		- file 对象使用 open 函数来创建，下表列出了 file 对象常用的方法
		- Python open() 方法用于打开一个文件，并返回文件对象。
		- 使用 open() 方法一定要保证关闭文件对象，即调用 close() 方法。
		- open() 函数常用形式是接收两个参数：文件名(file)和模式(mode)。
	- OS  文件/目录
		- **os** 模块提供了非常丰富的方法用来处理文件和目录
	- 错误和异常探索
		- 异常捕捉： try   / except
		- try/except...else
			- 语句还有一个可选的 **else** 子句，如果使用这个子句，那么必须放在所有的 except 子句之后。else 子句将在 try 子句没有发生任何异常的时候执行。
		- try -finally  语句无论是否发生异常都执行最后的代码
		- raise 抛出制定异常
	- 



- 模块
- 编程范式
- 

- 择时选股原理
	3.构建金融数据库
		3.1 构建金融数据库
		3.2 实战案例
	4.择时策略
		4.1 量化择时策略
		4.2 研报策略复现
	5.选股策略
		5.1 量化选股策略
		5.2 研报策略复现
- 多种策略
	- 1 择时策略
	- 美债择时
	- 策略评价
	2 选股策略
	- 因子构造
	- 因子分析
	- 多因子选股
	3 选股带择时策略



#### 类的方法
```python

__下划线都代表特殊情况
#类定义 
class people: 
	#定义基本属性 
	name = '' 
	age = 0 
	#定义私有属性,私有属性在类外部无法直接进行访问
	 __weight = 0 
	 #定义构造方法  里面是构造属性
	  def __init__(self,n,a,w): 
		  self.name = n 
		  self.age = a 
		  self.__weight = w 
	  def speak(self): 
		  print("%s 说: 我 %d 岁。" %(self.name,self.age)) 
		  # 实例化类 
	  p = people('runoob',10,30) p.speak()




```








#### 继承
普通继承
多重继承
方法重写



#### [类和方法](https://www.runoob.com/python3/python3-class.html)
<u>类的私有属性</u>
**__private_attrs**：两个下划线开头，声明该属性为私有，不能在类的外部被使用或直接访问。在类内部的方法中使用时 **self.__private_attrs**。

<u>类的方法</u>
在类的内部，使用 def 关键字来定义一个方法，与一般函数定义不同，类方法必须包含参数 self，且为第一个参数，self 代表的是类的实例。
self 的名字并不是规定死的，也可以使用 this，但是最好还是按照约定使用 self。

<u>类的私有方法</u>
**__private_method**：两个下划线开头，声明该方法为私有方法，只能在类的内部调用 ，不能在类的外部调用。**self.__private_methods**。


<u>类的专有方法：</u>
-   **__init__ :** 构造函数，在生成对象时调用
-   **__del__ :** 析构函数，释放对象时使用
-   **__repr__ :** 打印，转换
-   **__setitem__ :** 按照索引赋值
-   **__getitem__:** 按照索引获取值
-   **__len__:** 获得长度



#### 作用域

```python
g_count = 0  # 全局作用域
def outer():
    o_count = 1  # 闭包函数外的函数中
    def inner():
        i_count = 2  # 局部作用域

	```


![[Pasted image 20230302044503.png]]\


Python 中只有**模块（module），类（class）以及函数（def、lambda）**
才会引入新的作用域，其它的代码块**如 if/elif/else/、try/except、for/while等** 是不会引入新的作用域的，也就是说这些语句内定义的变量，外部也可以访问，如下代码：
```python


>>> def test():
...     msg_inner = 'I am from Runoob'
... 
>>> msg_inner
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
NameError: name 'msg_inner' is not defined



>>> if True:
...  msg = 'I am from Runoob'
... 
>>> msg
'I am from Runoob'
>>>

```



global 和 nonlocal  关键字

```python


num = 1 
def fun1(): 
    global num # 需要使用 global 关键字声明 
    print(num) 
    num = 123 p
    rint(num) 
    
fun1() 
print(num)


# 如果要修改嵌套作用域（enclosing 作用域，外层非全局作用域）中的变量则需要 nonlocal 关键字了

def outer(): 
		num = 10 
		def inner(): 
			nonlocal num # nonlocal关键字声明 
			num = 100 
			print(num) 
		inner() 
		print(num) 
outer()
```


> -  想象对表格的操作过程，
	目测有循环语句
	numpy的 broadcast

steps：
基础元素+操作
设计流程
按图索骥
范围品类 + MOB

dataframe  和series 之间的运算
pivot 多层索引   slice切片
pandas  多层索引
- 参考 [层次化索引](http://www.imooc.com/wiki/pandasless/hierarchicalindex.html)
pandas pivot函数
[官方文档](https://pandas.pydata.org/pandas-docs/stable/reference/api/pandas.pivot_table.html)
[他人笔记](https://blog.csdn.net/DiAsdream/article/details/124889380)


函数 def  return 和print的区别
``
```python
list = [1, -1, 2, -2, 3, -3]

def select_positive(x):
    return x > 0

def select_negative(x):
    return x < 0

def select(list, select_function):
    for item in list:
        if select_function(item):
            print(item)

select(list, select_positive)
select(list, select_negative)

```



#### Pivot
python——pivot_table，groupby - luckysusan1991的文章 - 知乎 https://zhuanlan.zhihu.com/p/50804981

从Excel到Python：最常用的36个Pandas函数！最完整的Pandas教程！ - 一枚程序媛的文章 - 知乎 https://zhuanlan.zhihu.com/p/97617276


Pandas | 一文看懂透视表pivot_table - rain的文章 - 知乎 https://zhuanlan.zhihu.com/p/31952948




用Python实现excel 14个常用操作 - 小匿的文章 - 知乎 https://zhuanlan.zhihu.com/p/30072060


#### 列表


#### 元组


#### 集合


#### 字典


