---
status: Backlog
due: 2023-03-11
published: false
weight: 4
tags:
  - pkm
  - obsidian
image: https://images.unsplash.com/photo-1550592704-6c76defa9985?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=300&q=80
---

# What I Learned From Taking 15,000 Notes