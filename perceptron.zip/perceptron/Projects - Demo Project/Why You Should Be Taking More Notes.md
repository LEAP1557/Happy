---
status: Doing
due: 2023-03-04
published: false
weight: 3
tags:
  - note-taking
  - pkm
image: https://images.unsplash.com/photo-1501504905252-473c47e087f8?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=300&q=80
---

# Why You Should Be Taking More Notes