---
status: Backlog
due: 2023-03-18
published: false
tags:
  - obsidian
image: https://images.unsplash.com/photo-1471107340929-a87cd0f5b5f3?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=300&q=80
---

# 5 Mistakes I Made When I Started Using Obsidian