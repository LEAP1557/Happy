---
status: Done
due: 2023-02-25
published: true
weight: 2
tags:
  - note-taking
  - obsidian
image: https://images.unsplash.com/photo-1488190211105-8b0e65b80b4e?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=300&q=80
---

# The Easiest Way to Start Taking Notes