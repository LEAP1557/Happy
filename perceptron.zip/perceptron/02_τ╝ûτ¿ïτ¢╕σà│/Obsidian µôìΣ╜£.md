



calendar
日历--日记
周历--周记

链接
- 双链：文章  段落
- 双链预览 
- 汇总页目录


Task代办事项
memo  灵感 类似 flomo
Quick Explorer

模版

``


daily notes+ calendar
1.  **[list|table|task]**： **Dataview** 有三种类型视图，列表，表格，任务，其中filed1，field字段等字段就是视图表头。
2.  **from** ：数据的来源，可以是文件夹，标签，链接。
3.  **where**： 筛选条件，支持field [>|>=|<|<=|=|&|'|'] [field2|literal value] (and field2 ...) (or field3...)这么多。
4.  **sort**：排序，按照某个关键字排序，有升序和降序，分别是为asc和desc。

具体例子
```text
list 
from ""
where contains(file.name,"每日反思")
sort file.ctime asc
```



### Dataview




### Advanced Table

https://pwa.sspai.com/post/72426



### Day Planner
https://www.zhihu.com/search?type=content&q=obsidian%20任务管理
选用code模式和daily note融合 ，做工作时间分配的日常track

https://zhuanlan.zhihu.com/p/541470934

https://zhuanlan.zhihu.com/p/403675420

https://zhuanlan.zhihu.com/p/403228404

### Tasks

```tasks not done due today sort by due ``` ```tasks done sort by priority reverse ``` ```tasks not done due before next monday sort by status sort by description reverse sort by path ``` ```tasks no due date path includes GitHub hide recurrence rule hide task count hide backlink ``` ```tasks not done heading includes OB插件 hide backlink exclude sub-items short mode limit 2 sort by priority ```


链接：https://zhuanlan.zhihu.com/p/440969902  

### Kanban
https://www.zhihu.com/search?type=content&q=obsidian%20任务管理


### Projects
https://www.youtube.com/watch?v=Ds-VPz7jIwM


### Python 
[视频](https://www.bilibili.com/video/BV1ze411K7bT/?is_story_h5=false&p=1&share_from=ugc&share_medium=android&share_plat=android&share_session_id=2bc60bec-ea91-4271-b017-af28840ced45&share_source=WEIXIN&share_tag=s_i&timestamp=1665159708&unique_k=zztmQBt&vd_source=3350fde2c0b267b819f3295c9b128088)


### 分栏

**插件名为multi-column-markdown**
相信你一定会遇到bug，此时你的解决方案有3条
缩减笔记栏宽
切换到另一笔记再切换回来即可
以上两条如不能解决，请去给开发者提issue

**总结**
打开需要分栏的笔记
单击需要分栏的位置
ctrl+P，检索co，运行Multi-column命令
设置栏数和添加去框线语句
在每一栏中输入笔记内容
切换到预览模式，即可看到分栏效果
遇到渲染bug：缩减栏宽；切换一下笔记再切回来
 作者：[维客笔记|分栏](https://www.bilibili.com/read/cv16275035?from=search&spm_id_from=333.337.0.0 )出处：bilibili




###  Obsidian Big Calendar
[来源](https://weibo.com/ttarticle/p/show?id=2309404741132801409689)


